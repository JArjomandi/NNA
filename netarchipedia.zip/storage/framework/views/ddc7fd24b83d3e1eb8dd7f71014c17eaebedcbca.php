<?php $__env->startSection('content'); ?>
    <section class="breadcrumbs">
        <div class="container">

            <div class="d-flex justify-content-between align-items-center">
                <h2>Register</h2>
            </div>

        </div>
    </section>
    <section class="inner-page">
        <div class="container">
            <form action="<?php echo e(route('register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3 mt-3">
                    <label for="network_name" class="form-label">Network Name</label>
                    <input type="text" class="form-control" id="network_name" placeholder="Enter Network Name" name="network_name">
                </div>
                <div class="mb-3">
                    <label for="categories" class="form-label">Categories (Comma seperated)</label>
                    <input type="text" class="form-control" id="categories" placeholder="Enter Categories" name="categories">
                </div>
                <div class="mb-3">
                    <label for="tags" class="form-label">Tags (Comma seperated)</label>
                    <input type="text" class="form-control" id="tags" placeholder="Enter Tags" name="tags">
                </div>
                <div class="mb-3">
                    <label for="year" class="form-label">Year</label>
                    <input type="text" class="form-control" id="year" placeholder="Enter Year" name="year">
                </div>
                <div class="mb-3">
                    <label for="paper_doi" class="form-label">Paper DOI</label>
                    <input type="text" class="form-control" id="paper_doi" placeholder="Enter Paper DOI" name="paper_doi">
                </div>
                <div class="mb-3">
                    <label for="link_to_paper" class="form-label">Link to Paper</label>
                    <input type="text" class="form-control" id="link_to_paper" placeholder="Enter Link to Paper" name="link_to_paper">
                </div>
                <div class="mb-3">
                    <label for="authors" class="form-label">Authors (Comma seperated)</label>
                    <input type="text" class="form-control" id="authors" placeholder="Enter Authors" name="authors">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\netarchipedia\resources\views/register.blade.php ENDPATH**/ ?>