<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/register', [HomeController::class, 'registerForm'])->name('register-form');
Route::post('/register', [HomeController::class, 'register'])->name('register');
Route::get('/update-form/{id}', [HomeController::class, 'updateForm'])->name('update-form');
Route::post('/update/{id}', [HomeController::class, 'update'])->name('update');
