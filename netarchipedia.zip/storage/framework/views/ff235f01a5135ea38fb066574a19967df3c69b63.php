<?php $__env->startSection('content'); ?>
    <section class="breadcrumbs">
        <div class="container">

            <div class="d-flex justify-content-between align-items-center">
                <h2>Latest articles</h2>
            </div>

        </div>
    </section>
    <section class="inner-page">
        <div class="container">
            <form action="<?php echo e(route('home')); ?>">
                <div class="row mb-3">
                    <div class="col-4">
                        <input name="search" type="text" class="form-control" id="search" placeholder="Search..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-3">
                        <button class="btn btn-primary">Search</button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-12">
                    <table class="table table-striped table-bordered table-responsive">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Network name</th>
                            <th scope="col">Categories</th>
                            <th scope="col">Tags</th>
                            <th scope="col">Year</th>
                            <th scope="col">Paper DOI</th>
                            <th scope="col">Link To Paper</th>
                            <th scope="col">Authors</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($article->id); ?></th>
                                <td><?php echo e($article->network_name); ?></td>
                                <td>
                                    <?php $__currentLoopData = explode(',', $article->categories); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('home', ['category' => ($item)])); ?>"><?php echo e($item); ?></a><?php if(!$loop->last): ?>,<br><?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = explode(',', $article->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('home', ['tag' => ($item)])); ?>"><?php echo e($item); ?></a><?php if(!$loop->last): ?>,<br><?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($article->year); ?></td>
                                <td><a href="<?php echo e($article->paper_doi); ?>"><?php echo e($article->paper_doi); ?></a></td>
                                <td><a href="<?php echo e($article->link_to_paper); ?>"><?php echo e($article->link_to_paper); ?></a></td>
                                <td>
                                    <?php $__currentLoopData = explode(',', $article->authors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('home', ['author' => ($item)])); ?>"><?php echo e($item); ?></a><?php if(!$loop->last): ?>,<br><?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\netarchipedia\resources\views/home.blade.php ENDPATH**/ ?>