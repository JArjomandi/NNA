@extends('master')
@section('content')
    <section class="breadcrumbs">
        <div class="container-fluid">

            <div class="d-flex justify-content-between align-items-center">
                <h2>Latest articles</h2>
            </div>

        </div>
    </section>
    <div class="container-fluid">
        <form action="{{ route('home') }}">
            <div class="row mb-3 mt-3">
                <div class="col-4">
                    <input name="search" type="text" class="form-control" id="search" placeholder="Search..." value="{{ request('search') }}">
                </div>
                <div class="col-3">
                    <button class="btn btn-primary">Search</button>
                </div>
            </div>
        </form>
        <div class="row mb-3">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Network name</th>
                            <th scope="col">Paper Title</th>
                            <th scope="col">Categories</th>
                            <th scope="col">Tags</th>
                            <th scope="col">Year</th>
                            <th scope="col">Paper DOI</th>
                            <th scope="col">Link To Paper</th>
                            <th scope="col">Authors</th>
                            <th scope="col">Google Scholar</th>
                            <th scope="col">BibTex</th>
                            <th scope="col">Conference</th>
                            <th scope="col">Operations</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($articles as $article)
                            <tr>
                                <th scope="row">{{ $article->id }}</th>
                                <td>{{ $article->network_name }}</td>
                                <td>{{ $article->paper_title }}</td>
                                <td>
                                    @foreach(explode(',', $article->categories) as $item)
                                        <a href="{{ route('home', ['category' => ($item)]) }}">{{ $item }}</a>@if(!$loop->last),<br>@endif
                                    @endforeach
                                </td>
                                <td>
                                    @foreach(explode(',', $article->tags) as $item)
                                        <a href="{{ route('home', ['tag' => ($item)]) }}">{{ $item }}</a>@if(!$loop->last),<br>@endif
                                    @endforeach
                                </td>
                                <td>{{ $article->year }}</td>
                                <td><a href="{{ $article->paper_doi }}">{{ $article->paper_doi }}</a></td>
                                <td><a href="{{ $article->link_to_paper }}">Click</a></td>
                                <td>
                                    @foreach(explode(',', $article->authors) as $item)
                                        <a href="{{ route('home', ['author' => ($item)]) }}">{{ $item }}</a>@if(!$loop->last),<br>@endif
                                    @endforeach
                                </td>
                                <td><a href="{{ $article->google_scholar }}">Click</a></td>
                                <td><a href="{{ $article->bibtex }}">Click</a></td>
                                <td>{{ $article->conference }}</td>
                                <td><a href="{{ route('update-form', $article->id) }}"><b class="text-danger">Request edit</b></a></td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
