<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\EditRequest;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request){
        $articles = Article::query()
            ->when($request->has('search'), function ($query) use ($request){
                return $query->where(function ($subQuery) use ($request){
                    $subQuery->where('network_name', 'like', '%'. $request->search .'%')
                        ->orWhere('categories', 'like', '%'. $request->search .'%')
                        ->orWhere('tags', 'like', '%'. $request->search .'%')
                        ->orWhere('year', 'like', '%'. $request->search .'%')
                        ->orWhere('paper_doi', 'like', '%'. $request->search .'%')
                        ->orWhere('link_to_paper', 'like', '%'. $request->search .'%')
                        ->orWhere('conference', 'like', '%'. $request->search .'%')
                        ->orWhere('paper_title', 'like', '%'. $request->search .'%')
                        ->orWhere('authors', 'like', '%'. $request->search .'%');
                });
            })->when($request->has('tag'), function ($query) use ($request){
                return $query->where(function ($subQuery) use ($request){
                    $subQuery->where('tags', 'like', '%'. $request->tag .'%');
                });
            })->when($request->has('category'), function ($query) use ($request){
                return $query->where(function ($subQuery) use ($request){
                    $subQuery->where('categories', 'like', '%'. $request->category .'%');
                });
            })->when($request->has('author'), function ($query) use ($request){
                return $query->where(function ($subQuery) use ($request){
                    $subQuery->where('authors', 'like', '%'. $request->author .'%');
                });
            });

        $articles = $articles->orderByDesc('id')->take(100)->get();
        return view('home', compact('articles'));
    }

    public function registerForm(Request $request){
        return view('register');
    }

    public function register(Request $request){
        $request->validate([
            'paper_doi' => ['required'],
        ]);
        $article = new Article();
        $this->updateOrCreate($article, $request);

        return redirect()->back()->with('success', 'Submitted successfully');
    }

    public function updateForm(Request $request, $id){
        $article = Article::query()->findOrFail($id);
        return view('register', compact('article'));
    }

    public function update(Request $request, $id){
        $article = Article::query()->findOrFail($id);
        $request->validate([
            'paper_doi' => ['required'],
        ]);
        $edit_request = new EditRequest();
        $edit_request->article_id = $article->id;
        $edit_request->network_name = $request->network_name;
        $edit_request->paper_title = $request->paper_title;
        $edit_request->categories = $request->categories;
        $edit_request->tags = $request->tags;
        $edit_request->year = $request->year;
        $edit_request->paper_doi = $request->paper_doi;
        $edit_request->link_to_paper = $request->link_to_paper;
        $edit_request->authors = $request->authors;
        $edit_request->google_scholar = $request->google_scholar;
        $edit_request->bibtex = $request->bibtex;
        $edit_request->conference = $request->conference;
        $edit_request->save();

        return redirect()->back()->with('success', "Your edit request has been submitted and will be published after the administrator's review.");
    }

    public function updateOrCreate($article, $request){
        $article->network_name = $request->network_name;
        $article->paper_title = $request->paper_title;
        $article->categories = $request->categories;
        $article->tags = $request->tags;
        $article->year = $request->year;
        $article->paper_doi = $request->paper_doi;
        $article->link_to_paper = $request->link_to_paper;
        $article->authors = $request->authors;
        $article->google_scholar = $request->google_scholar;
        $article->bibtex = $request->bibtex;
        $article->conference = $request->conference;
        $article->save();
        return $article;
    }
}
